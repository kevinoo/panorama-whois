
CREATE TABLE tlds (
	tld varchar PRIMARY KEY,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE countries (
    code varchar(5) PRIMARY KEY NOT NULL,
    iso2 varchar(2),
    name varchar(150),
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp
);

CREATE TABLE iana_registry (
    id int NOT NULL PRIMARY KEY,
    name varchar(255) NOT NULL,
    status varchar(100) NOT NULL,
    link varchar(255) NOT NULL,
    phone varchar(20) NOT NULL,
    abuse_email varchar(40) NOT NULL
);

CREATE TABLE iana_address_blocks (
    prefix int PRIMARY KEY,
    designation varchar(100),
    date varchar(7),
    whois varchar(100),
    rdap  varchar(100),
    status  varchar(20)
);

CREATE TABLE ip_ranges_by_countries (
    ip_from bigint NOT NULL,
    ip_to bigint NOT NULL,
    country_code varchar(2) NOT NULL,

    PRIMARY KEY (ip_from,ip_to)
);

CREATE TABLE cached_ocr_requests (
	image_url varchar PRIMARY KEY,
	content varchar,
	created_at timestamp DEFAULT CURRENT_TIMESTAMP,
	expired_at timestamp DEFAULT (datetime('now', '+14 days'))
);
