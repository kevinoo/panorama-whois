
CREATE TABLE domains (
	tld varchar PRIMARY KEY,
	who_is_data jsonb,
	created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
	updated_at timestamp
);
