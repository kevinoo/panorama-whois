
CREATE TABLE domains (
	tld varchar PRIMARY KEY NOT NULL,
	who_is_data jsonb,
	created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
	updated_at timestamp
);

